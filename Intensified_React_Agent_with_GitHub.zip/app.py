import time

import streamlit as st

from agent.react_agent import ReactAgent

st.title("个人智能助理")
st.divider()

if "agent" not in st.session_state:
    st.session_state["agent"] = ReactAgent()

if "session_id" not in st.session_state:
    st.session_state["session_id"] = "default"

if "message" not in st.session_state:
    st.session_state["message"] = []

for message in st.session_state["message"]:
    st.chat_message(message["role"]).write(message["content"])

prompt = st.chat_input("请输入问题，例如：根据我的资料，给我当前项目推进建议")

if prompt:
    st.chat_message("user").write(prompt)
    st.session_state["message"].append({"role": "user", "content": prompt})
    response_messages = []

    with st.spinner("个人智能助理思考中..."):
        res_stream = st.session_state["agent"].execute_stream(prompt, session_id=st.session_state["session_id"])

        def capture(generator, cache_list):
            for chunk in generator:
                cache_list.append(chunk)
                for char in chunk:
                    time.sleep(0.005)
                    yield char

        st.chat_message("assistant").write_stream(capture(res_stream, response_messages))
        st.session_state["message"].append({"role": "assistant", "content": "".join(response_messages).strip()})
        st.rerun()
