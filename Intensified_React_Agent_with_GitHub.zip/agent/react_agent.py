from __future__ import annotations

from langchain.agents import create_agent

from agent.tools.agent_tools import (
    rag_summarize,
    save_memory_episode,
    save_memory_fact,
    save_memory_rule,
    search_episodic_memory,
    search_procedural_memory,
    search_semantic_memory,
)
from agent.tools.middleware import log_before_model, monitor_tool
from memory.memory_manager import MemoryManager
from model.factory import chat_model
from utils.prompt_loader import load_system_prompts


class ReactAgent:
    def __init__(self):
        self.memory = MemoryManager()
        self.agent = create_agent(
            model=chat_model,
            system_prompt=load_system_prompts(),
            tools=[
                rag_summarize,
                search_semantic_memory,
                search_procedural_memory,
                search_episodic_memory,
                save_memory_fact,
                save_memory_rule,
                save_memory_episode,
            ],
            middleware=[monitor_tool, log_before_model],
        )

    def _build_user_message(self, session_id: str, query: str) -> str:
        memory_context = self.memory.format_context(session_id=session_id, query=query)
        if not memory_context:
            return query
        return (
            "以下是当前问题可用的记忆上下文，请优先参考这些信息，再结合知识库回答。\n\n"
            f"{memory_context}\n\n"
            f"【当前问题】\n{query}"
        )

    def execute_stream(self, query: str, session_id: str = "default"):
        self.memory.append_conversation(session_id, "user", query)
        final_chunks: list[str] = []
        input_dict = {"messages": [{"role": "user", "content": self._build_user_message(session_id, query)}]}

        for chunk in self.agent.stream(input_dict, stream_mode="values"):
            latest_message = chunk["messages"][-1]
            if latest_message.content:
                text = latest_message.content.strip()
                final_chunks.append(text)
                yield text + "\n"

        final_answer = "\n".join(final_chunks).strip()
        if final_answer:
            self.memory.append_conversation(session_id, "assistant", final_answer)
            self.memory.extract_and_persist(session_id, query, final_answer)


if __name__ == '__main__':
    agent = ReactAgent()
    for chunk in agent.execute_stream("根据我的资料，给我一个当前项目推进建议"):
        print(chunk, end="", flush=True)
