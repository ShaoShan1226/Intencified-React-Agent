from __future__ import annotations

from langchain_core.tools import tool

from memory.memory_manager import MemoryManager
from rag.rag_service import RagSummarizeService

rag = RagSummarizeService()
memory = MemoryManager()


@tool(description="从个人知识库和资料库中检索参考资料，并返回总结结果")
def rag_summarize(query: str) -> str:
    return rag.rag_summarize(query)


@tool(description="按查询词检索长期事实记忆，返回与个人背景、经历、项目、偏好相关的内容")
def search_semantic_memory(query: str) -> str:
    items = memory.semantic.search(query, limit=5)
    if not items:
        return ""
    return "\n".join([f"{item['category']} / {item['key']}：{item['value']}" for item in items])


@tool(description="按查询词检索长期规则记忆，返回与决策逻辑、写作偏好、工程原则相关的内容")
def search_procedural_memory(query: str) -> str:
    items = memory.procedural.search(query, limit=5)
    if not items:
        return ""
    return "\n".join([f"{item['rule_type']}：{item['rule_text']}" for item in items])


@tool(description="按查询词检索阶段性经历记忆，返回过去讨论过的主题和总结")
def search_episodic_memory(query: str) -> str:
    items = memory.episodic.search(query, limit=3)
    if not items:
        return ""
    return "\n".join([f"{item['topic']}：{item['summary']}" for item in items])


@tool(description="手动写入长期事实记忆。入参格式：category|key|value")
def save_memory_fact(payload: str) -> str:
    try:
        category, key, value = [part.strip() for part in payload.split("|", 2)]
        memory.semantic.upsert(category=category, key=key, value=value, source="tool")
        return "长期事实记忆已保存"
    except Exception:
        return "写入失败，格式应为：category|key|value"


@tool(description="手动写入长期规则记忆。入参格式：rule_type|rule_text|priority")
def save_memory_rule(payload: str) -> str:
    try:
        rule_type, rule_text, priority = [part.strip() for part in payload.split("|", 2)]
        memory.procedural.upsert(rule_type=rule_type, rule_text=rule_text, priority=int(priority), source="tool")
        return "长期规则记忆已保存"
    except Exception:
        return "写入失败，格式应为：rule_type|rule_text|priority"


@tool(description="手动写入阶段性经历记忆。入参格式：topic|summary")
def save_memory_episode(payload: str) -> str:
    try:
        topic, summary = [part.strip() for part in payload.split("|", 1)]
        memory.episodic.add(session_id="manual", topic=topic, summary=summary, source="tool")
        return "阶段性经历记忆已保存"
    except Exception:
        return "写入失败，格式应为：topic|summary"
